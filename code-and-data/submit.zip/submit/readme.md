# BIU-DeepLearning-Sequences-3
Task No. 3 in deep learning for sequences course by Yoav Goldberg. semester b year 23-24

Roee esquira, ID 309840791
Yedidia Kfir, ID 209365188